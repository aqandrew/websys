Name: Andrew Aquino
RCS ID: aquina
RIN: 661372532

Advice for next time: It would help a ton if, in the instructions, it's mentioned that
	1) httpd-vhosts.conf is the config file we're supposed to edit
	2) the <Directory> tag needs to be included before the <VirtualHost> tag