I couldn't decide whether to put the HTML signature in labs or homework, so I made a new section for it called "Classwork".

Is there a way to append an HTML file which has its own styling (i.e. the HTML signature) to the bottom of another?