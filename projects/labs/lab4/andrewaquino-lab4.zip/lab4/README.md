I wrapped the genres in a <div> to allow each bulleted item to line-break while retaining the correct vertical alignment.

I wasn't sure how we were supposed to insert all of our song data in the starter HTML file, which included only one set of tags representing a song, identified by ids instead of classes.
Click the album art repeatedly to cycle through my favorite songs!