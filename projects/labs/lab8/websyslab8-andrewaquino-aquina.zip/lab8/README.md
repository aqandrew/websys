# Observations

How were so many students able to come up with viable dummy data within the first hour of class? This was by far the most time-consuming part of the lab.

# Assumptions

When creating a field in some table, even if it was a primary key, if the instructions didn't explicitly specify "not null", I alllowed it to be null.

# References

https://yacs.cs.rpi.edu/
https://www.mockaroo.com/#
http://stackoverflow.com/questions/14196427/how-to-get-nth-highest-value-using-plain-sql